<?php
declare(strict_types=1);
require_once('autoload.php');


$atualizador = new AtualizadorDeContas(0.01);

$c = new Conta(1, "Fulano");
$cc = new ContaCorrente(2, "Beltrano");
$cp = new ContaPoupanca(3, "Ciclano");

$atualizador->atualizaConta($c);
$atualizador->atualizaConta($cc);
$atualizador->atualizaConta($cp);

echo "Saldo total das contas atualizadas: R\${$atualizador->getSaldoTotalDasContasAtualizadas()}";