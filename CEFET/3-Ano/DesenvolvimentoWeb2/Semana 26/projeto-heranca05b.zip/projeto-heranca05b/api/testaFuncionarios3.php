<?php
    declare(strict_types=1);
    require_once('autoload.php');

    //$f1 = new Funcionario("Bigode");
    //$f1->setSalario(2000);
    $g1 = new Gerente("Maria Eduarda",123);
    $g1->setSalario(5000);
    $g2 = new Gerente("Ana Beatriz",124);
    $g2->setSalario(5000);
    $t1 = new Tesoureiro("Bruno");
    $t1->setSalario(3000);
    $c1 = new Caixa("Jevaux");
    $c1->setSalario(2000);
    $d1 = new Diretor("Deputado", 123);
    $d1->setSalario(8000);

    /*echo "<hr/>Dados do funcionário 1:<hr/>";
    $f1->exibeDados();
    echo "Bonificação: R\${$f1->getBonificacao()}<br/>";*/
    echo "<hr/>Dados do gerente 1:<hr/>";
    $g1->exibeDados();
    echo "Bonificação: R\${$g1->getBonificacao()}<br/>";
    echo "<hr/>Dados do gerente 2:<hr/>";
    $g2->exibeDados();
    echo "Bonificação: R\${$g2->getBonificacao()}<br/>";
    echo "<hr/>Dados do tesoureiro 1:<hr/>";
    $t1->exibeDados();
    echo "Bonificação: R\${$t1->getBonificacao()}<br/>";
    echo "<hr/>Dados do caixa 1:<hr/>";
    $c1->exibeDados();
    echo "Bonificação: R\${$c1->getBonificacao()}<br/>";
    echo "<hr/>Dados do diretor 1:<hr/>";
    $d1->exibeDados();
    echo "Bonificação: R\${$d1->getBonificacao()}<br/>";
?>
