<?php 

    interface AreaCalculavel{
        public function calculaArea():float;
    }

    