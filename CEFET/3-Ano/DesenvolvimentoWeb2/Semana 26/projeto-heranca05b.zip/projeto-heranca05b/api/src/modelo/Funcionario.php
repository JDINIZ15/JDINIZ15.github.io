<?php
    abstract class Funcionario{
        protected string $nome, $departamento;
        protected float $salario;
        //Construtor ($nome obrigatório)
        public function __construct(string $nome, string $departamento = "NÃO DEFINIDO", float $salario = 1000.0)
        {
            $this->setNome($nome); 
            if(isset($departamento) && $departamento!=="") 
                $this->setDepartamento($departamento);
            $this->setSalario($salario);
        }
        //comportamentos
        public function aumentaSalario(float $percentualDeAumento):void{
            if( $percentualDeAumento >0 && $percentualDeAumento <=100)
                $this->salario += (($this->salario * $percentualDeAumento)/100);
        }

        public abstract function getBonificacao():float;
        
        public function exibeDados():void{
            echo "Nome: {$this->getNome()}<br/>";
            echo "Departamento: {$this->getDepartamento()}<br/>";
            echo "Salário: R\${$this->getSalario()}<br/>";          
        }
        //Métodos acessores (get e set)
        public function setNome(string $nome):void{
            //Deve ter alguma validação
            $this->nome = $nome;
        }
        public function getNome():string{
            return $this->nome;
        }
        public function setDepartamento(string $departamento):void{
            //Deve ter alguma validação
            $this->departamento = $departamento;
        }
        public function getDepartamento():string{
            return $this->departamento;
        }
        public function setSalario(float $salario):void{
            if(! $salario>=1000.0)
                die("Salário inválido. Aplicação será encerrada.");
            $this->salario = $salario;
        }
        public function getSalario():float{
            return $this->salario;
        }
    }