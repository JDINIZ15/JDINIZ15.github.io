<?php 


    class CalculadorDeArea{
        public function imprimir(AreaCalculavel $figuraGeometrica):void{
            echo "A área desta figura é {$figuraGeometrica->calculaArea()}<br/>";
        }
    }