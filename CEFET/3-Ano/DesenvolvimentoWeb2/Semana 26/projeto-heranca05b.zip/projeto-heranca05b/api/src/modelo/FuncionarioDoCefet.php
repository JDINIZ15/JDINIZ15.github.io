<?php
class FuncionarioDoCefet extends Funcionario{
    protected int $matriculaSiape;

    public function __construct(string $nome, string $departamento = "NÃO DEFINIDO", float $salario = 1000.0)
    {
        parent::__construct($nome, $departamento, $salario);
    }

    //comportamente
    public function getGastos():float{
        return $this->getSalario();
    }

    public function getInfo():string{
        return "Nome: {$this->nome}, salário: R\${$this->salario} ";
    }

    public function getMatriculaSiape():int{
        return $this->matriculaSiape;
    }
    public function setMatriculaSiape(int $matriculaSiape):void{
        //Pode haver regra de negócio
        $this->matriculaSiape = $matriculaSiape;
    }
}
