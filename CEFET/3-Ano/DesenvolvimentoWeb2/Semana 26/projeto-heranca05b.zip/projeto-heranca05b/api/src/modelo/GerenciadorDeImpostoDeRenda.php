<?php 
class GerenciadorDeImpostoDeRenda{

    public function __construct()
    {
        ;
    }
    private float $totalEmTributos = 0.0;

    public function acumulaTributos(Tributavel $t){
        $this->totalEmTributos += $t->calculaTributos();
    }

    public function getTotalEmTributos():float{
        return $this->totalEmTributos;
    }
}