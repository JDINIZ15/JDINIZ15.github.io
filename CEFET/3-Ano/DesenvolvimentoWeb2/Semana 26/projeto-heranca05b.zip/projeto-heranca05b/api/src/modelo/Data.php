<?php
    class Data{
        //Atributos
        private string $dia, $mes, $ano;
        //Comportamento
        public function getDataBR():string{
            return $this->dia."/".$this->mes."/".$this->ano;
        }
        //Métodos acessores
        public function setDia(string $dia):void{
            if(strlen($dia)!=2)
                die("Valor inválido para dia. Aplicação será encerrada.<br/>");
            $this->dia = $dia;
        }
        public function getDia():string{
            return $this->dia;
        }

        public function setMes(string $mes):void{
            if(strlen($mes)!=2)
                die("Valor inválido para mês. Aplicação será encerrada.<br/>");
            $this->mes = $mes;
        }
        public function getMes():string{
            return $this->mes;
        }

        public function setAno(string $ano):void{
            if(strlen($ano)!=4)
                die("Valor inválido para ano. Aplicação será encerrada.<br/>");
            $this->ano = $ano;
        }
        public function getAno():string{
            return $this->ano;
        }
    }
?>