<?php
class GeradorDeRelatorio{
    public function imprime(FuncionarioDoCefet $func):void{
        echo "{$func->getInfo()}";
        echo "Gastos: {$func->getGastos()}<hr/>";
    }
}
