<?php 
    declare(strict_types=1);

    class Quadrado implements AreaCalculavel{
        //Declaração de atributos readonly (atributo imutável) no construtor
        public function __construct(public readonly float $lado)
        {
            //Atribuição automática. Seria necessário criar um método p/ validar os atributos
        }
        
        //Dispensa método get. O acesso p/ leitura no script de testes seria algo como
        //$quad = new Quadrado(10); echo "Lado: {$quad->lado}.<br/>";

        public function calculaArea(): float
        {
            return $this->lado * $this->lado;
        }

        //Boa prática
        public function toArray(): array
        {
            return [  
                'lado' => $this->lado
            ];
        }
    }

