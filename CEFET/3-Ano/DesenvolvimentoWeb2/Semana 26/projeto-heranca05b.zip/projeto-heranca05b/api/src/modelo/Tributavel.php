<?php 


interface Tributavel{
    public function calculaTributos():float;
}