<?php
    class Empresa{
        private string $nome, $cnpj;
        private array $empregados;

        public function __construct()
        {
            $this->empregados = array();
        }

        public function adicionaEmpregado(Funcionario $emp){
            array_push($this->empregados, $emp);
        }
        public function adicionaVariosEmpregados(array $empregados){
            if(! $this->verificaArrayDeEmpregados($empregados) )
                die("O array precisa conter apenas objetos do tipo Funcionario. Aplicação encerrada.<br/>");
            $this->empregados = array_merge($this->empregados, $empregados);
        }
        //Método encapsulado
        private function verificaArrayDeEmpregados(array $empregados):bool{
            foreach($empregados as $empregado){
                if(! $empregado instanceof Funcionario)
                    return false;
            }
            return true;
        }
        public function estaNaEmpresa(Funcionario $empregado):bool{
            //O 3º argumento força uma checagem de tipos também
            return in_array($empregado, $this->empregados,TRUE);
        }
        public function removeEmpregado(Funcionario $empregado):void{
            $chave = array_search($empregado, $this->empregados);
            if($chave !== false)
                unset($this->empregados[$chave]);
        }

        public function setNome(string $nome):void{
            if( !strlen($nome)>=4)
                die("Nome inválido. A aplicação será encerrada.<br/>");
            $this->nome = $nome;
        }
        public function getNome():string{
            return $this->nome;
        }
        public function setCnpj(string $cnpj):void{
            $this->cnpj = $cnpj;
        }
        public function getCnpj():string{
            return $this->cnpj;
        }
        public function getEmpregados():array{
            return $this->empregados;
        }
        
    }
?>