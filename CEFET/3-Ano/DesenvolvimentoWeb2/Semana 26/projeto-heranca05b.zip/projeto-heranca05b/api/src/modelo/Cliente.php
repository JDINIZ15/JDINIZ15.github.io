<?php
    class Cliente implements Autenticavel{
        private string $nome;
        private string $cpf;
        private string $email;
        protected int $senha;
        public function setSenha(int $senha):void{
            //É possível que haja alguma regra aqui
            $this->senha = $senha;
        }
        public function getSenha():int{
            return $this->senha;
        }

        public function autentica(int $senhaExterna):bool{
            return ($this->senha === $senhaExterna);
        }
        //Construtor
        public function __construct(string $nome = "")
        {
            if($nome!="")
                $this->setNome( $nome );
        }

        //Método encapsulado
        private function validaCpf(string $cpf):bool{
            //if( strlen($cpf) === 14 && $cpf[3]==="." && strpos($cpf,".",4)===7 && strpos($cpf,"-")===11 )
            if( strlen($cpf) === 14 && $cpf[3]==="." && substr($cpf,7,1)==="." && strpos($cpf,"-")===11 )
                return true;
            return false;
        }
        //Comportamento
        public function exibeDados():void{
            echo "Nome: {$this->getNome()}<br/>";
            echo "Cpf: {$this->getCpf()}<br/>";
            echo "E-mail: {$this->getEmail()}<br/>";
        }
        //métodos acessores (get e set)
        public function setNome(string $nome):void{
            if( strlen( $nome <3 ))
                die("Nome precisa ter ao menos 3 caracteres. Aplicação será encerrada. <br/>");
            $this->nome = $nome;
        }
        public function getNome():string{
            return $this->nome;
        }
  
        public function getCpf():string{
            return $this->cpf;
        }
        public function setCpf(string $cpf):void{
            if( ! $this->validaCpf( $cpf ) )
                die("Cpf inválido. Aplicação será encerrada. <br/>");
            $this->cpf = $cpf;
        }
        public function setEmail(string $email):void{
            if( !(strpos($email, "@")>0 && strpos($email, ".")>0) )
                die("E-mail inválido. A aplicação será encerrada.");
            $this->email = $email;
        }
        public function getEmail():string{
            return $this->email;
        } 
    }
?>