<?php
    class GerenciadorDeBonificacoes{
        private float $totalEmBonificacoes = 0.0;//Não tem set

        public function somaBonificacao(Funcionario $f){
            $this->totalEmBonificacoes += $f->getBonificacao();
        }

        public function getTotalEmBonificacoes():float{
            return $this->totalEmBonificacoes;
        }
    }