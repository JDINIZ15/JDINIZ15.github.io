<?php 


    interface Autenticavel{
        public function autentica(int $senha):bool;
    }
    