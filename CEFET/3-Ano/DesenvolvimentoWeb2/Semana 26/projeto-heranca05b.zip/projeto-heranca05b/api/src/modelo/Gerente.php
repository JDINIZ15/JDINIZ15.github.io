<?php

    class Gerente extends Funcionario implements Autenticavel{
        protected int $senha;

        public function __construct(string $nome, int $senha, string $departamento = "NÃO DEFINIDO", float $salario = 1000.0){
            //Tem que ser a primeira linha
            parent::__construct($nome, $departamento, $salario);
            $this->setSenha($senha);
        }
        
        public function setSenha(int $senha):void{
            //É possível que haja alguma regra aqui
            $this->senha = $senha;
        }
        public function getSenha():int{
            return $this->senha;
        }

        public function autentica(int $senhaExterna):bool{
            return ($this->senha === $senhaExterna);
        }

        public function getBonificacao():float{
            return $this->salario * 0.30;
        }
    }
?>
