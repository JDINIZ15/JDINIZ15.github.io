<?php 
    declare(strict_types=1);

    class Circulo implements AreaCalculavel{
        //Mesma situação do Quadrado
        public function __construct(public readonly float $raio)
        {}

        public function getRaio():float{
            return $this->raio;
        }

        public function calculaArea(): float
        {
            return $this->raio * M_PI;
        }

        //Boa prática
        public function toArray(): array
        {
            return [
                'raio' => $this->raio
            ];
        }
    }
    
    