<?php
    class Conta{
        //Atributos
        protected int $numero;//Princípio da imutabilidade
        protected float $saldo = 0;
        protected string $nomeDoTitular="";

        //Construtor e destrutor
        public function __construct(int $numero, string $nomeDoTitular = "")
        {
            if( $numero<=0 ){
                echo "Não é possível criar uma conta com número inválido.<br/>";
                die("A aplicação será encerrada");
            }
            $this->numero = $numero;
            if($nomeDoTitular !== "")
                $this->setNomeDoTitular($nomeDoTitular);
        }

        //Métodos acessores
        public function getNumero():int{
            return $this->numero;
        }   
        public function getSaldo():float{
            return $this->saldo;
        }
        public function getNomeDoTitular():string{
            return $this->nomeDoTitular;
        }
        public function setNomeDoTitular(string $nomeDoTitular):void{
            //Pode haver alguma regra aqui
            $this->nomeDoTitular = $nomeDoTitular;
        }
        //Comportamento
        public function atualiza(float $taxa):void{
            $this->saldo -= $taxa;
        }
        public function saca(float $valor):bool{
            if( $valor <=0 || $valor> $this->saldo )
                return false;
            $this->saldo -= $valor;
            return true;
        }
        public function deposita(float $valor):bool{
            if( $valor<= 0 )
                return false;
            $this->saldo += $valor;
            return true;
        }
        public function transferePara(Conta $contaDestino, float $valor):bool{
            if( $this->saca($valor) )
                return $contaDestino->deposita($valor);
            return false;
        }
        public function exibeDados():void{
            echo "Número: {$this->numero}<br/>";
            echo "Nome do titular: {$this->nomeDoTitular}<br/>";
            echo "Saldo: R\${$this->saldo}<br/>";
        }
    }
?>