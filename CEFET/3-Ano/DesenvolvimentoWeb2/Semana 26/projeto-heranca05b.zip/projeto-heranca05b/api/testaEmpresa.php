<?php
    declare(strict_types=1);
    require_once('autoload.php');

    $empresa = new Empresa();
    $empresa->setNome("CEFET");

    $func1 = new Funcionario("Mariana");
    $func1->setDepartamento("Vendas");
    $func1->setSalario(5000);

    $func2 = new Funcionario("Ricardo");
    $func2->setDepartamento("Recursos Humanos");
    $func2->setSalario(5000);

    $func3 = new Funcionario("Pedro");
    $func3->setNome("Pedro Silva");
    $func3->setDepartamento("Contabilidade");
    $func3->setSalario(7000);

    $empregados = array();
    $empregados[0] = $func2;
    array_push($empregados, $func3);

    $func1->aumentaSalario(20);

    $empresa->adicionaEmpregado($func1);
    $empresa->adicionaVariosEmpregados($empregados);

    foreach($empresa->getEmpregados() as $empregado){
        if($empregado!==null){
            $empregado->exibeDados();
            echo "<hr/>";
        }
    }

?>