<?php 
declare(strict_types=1);
require_once('autoload.php');

$contaCorrente = new ContaCorrente(5,"Fulano");
$contaCorrente->deposita(1000);

$seguroDeVida = new SeguroDeVida();

$gerenciadorDeIR = new GerenciadorDeImpostoDeRenda();

$gerenciadorDeIR->acumulaTributos($contaCorrente);
$gerenciadorDeIR->acumulaTributos($seguroDeVida);

echo "O total em impostos é R\${$gerenciadorDeIR->getTotalEmTributos()}";
