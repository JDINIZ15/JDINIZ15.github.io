<?php
declare(strict_types=1);
require_once('autoload.php');


$gerador = new GeradorDeRelatorio();

$f1 = new FuncionarioDoCefet("Fulano","SINFO",3000);
$p1 = new ProfessorDoCefet("Beltrano","SISTEMAS", 12000);

echo "Relatório: <br/><hr/>";
$gerador->imprime($f1);
$gerador->imprime($p1);

