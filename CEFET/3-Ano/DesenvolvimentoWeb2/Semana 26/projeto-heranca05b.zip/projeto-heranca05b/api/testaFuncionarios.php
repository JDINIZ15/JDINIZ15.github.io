<?php
    declare(strict_types=1);
    require_once('autoload.php');

    $func1 = new Funcionario("Mariana");
    $func1->setNome("Mariana da Silva");
    $func1->setDepartamento("Vendas");
    $func1->setSalario(5000);

    $func2 = new Funcionario("Ricardo");
    $func2->setDepartamento("Recursos Humanos");
    $func2->setSalario(5000);


    $func1->aumentaSalario(20);

    echo "Dados do funcionário 1:<br/>";
    echo "Nome: {$func1->getNome()}<br/>";
    echo "Departamento: {$func1->getDepartamento()}<br/>";
    echo "Salário: R\${$func1->getSalario()}<br/>";

    echo "<hr/>";

    echo "Dados do funcionário 2:<br/>";
    $func2->exibeDados();
?>
