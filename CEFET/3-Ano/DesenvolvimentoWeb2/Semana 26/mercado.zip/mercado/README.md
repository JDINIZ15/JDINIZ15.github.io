# Informações

> Sistema CRUD com arquitetura MVC, API REST rústica, URLs amigáveis, OO, entre outros

- Professor [Rafael Guimarães Rodrigues]
- Turma de Desenvolvimento Web II (2025)


## Requisitos de software (XAMPP ou WAMP)
- [Apache](https://apache.org/) 2.4
- [MariaDB](https://mariadb.com/) 10

## No phpMyAdmin (XAMPP ligado com os serviços Apache e MySql rodando)

Copiar todo o conteúdo de instrucoesSql.sql e executar para gerar a base de dados e as tabelas.

## No composer

1. Abrir o prompt de comando na pasta api

executar os comandos abaixo:
composer install
composer dumpautoload -o 
e posteriormente executar o dumpautoload a cada classe acrescentada.

### Configuração no Windows

1. Ligar os servidores do Apache e do MariaDB.

2. Adicionar em `C:\Windows\System32\drivers\etc\hosts`:

127.0.0.1 mercado.cefet

3. Adicionar em `C:/dev/xampp/apache/conf/extra/httpd-vhosts.conf`:

<VirtualHost mercado.cefet:80>
    ServerName mercado.cefet
    DocumentRoot "C:/dev/xampp/htdocs/mercado"
    ErrorDocument 404 "/404"
	<Directory "C:/dev/xampp/htdocs/mercado">
		# Permite ajustes na configuração do Apache via .htaccess
        AllowOverride All
    </Directory>
</VirtualHost>

> ⚠️ Atenção: Trocar `C:/dev/xampp/htdocs/` pelo diretório correto da sua máquina.

4. Reiniciar o Apache (XAMPP).

### Execução do projeto

Abrir http://mercado.cefet.



