import { listar, salvar, remover, obter } from "./requisicoes.js";
import { exibirErro, preencherHtml } from "../util.js";
const spanErro = document.querySelector('#msgErro');
//Ao carregar a árvore do DOM
document.addEventListener("DOMContentLoaded", async () => {
    try{
        let registros = await listar();
        montarTabela(registros);
    }catch( e ){//4xx/5xx
        exibirErro( spanErro , '('+e.status+') '+e, 3000);
    } 
}); //Fim de Ao carregar a árvore do DOM

//registrar evento submit do FORM
const formUsuario = document.querySelector("#form-usuarios");
formUsuario.addEventListener("submit", async (e) => {
    e.preventDefault();
    let usuario = {
        id: document.querySelector("#id").value,
        nome: document.querySelector("#nome").value
    }
    const id = Number(usuario.id);
    if(!id>0 && document.querySelector('#login') && document.querySelector('#senha') && document.querySelector('#senha2')){
        usuario.login = document.querySelector('#login').value;
        usuario.senha = document.querySelector('#senha').value;
        usuario.senha2 = document.querySelector('#senha2').value;
    }

    try{
        await salvar(usuario);
        formUsuario.reset();
        document.querySelector("#id").value='';
        /*document.querySelector("#login").disabled = false;
        document.querySelector("#senha").disabled = false;
        document.querySelector("#senha2").disabled = false;*/

        let registros = await listar();
        montarTabela(registros);
    }catch( e ){//4xx/5xx
        exibirErro( spanErro , '('+e.status+') '+e, 3000);
    }
});

//Declarar eventos do corpo da tabela (click em EDITAR ou EXCLUIR)
document.querySelector("#tbl-usuarios tbody").addEventListener("click", async (e) => {
    const alvo = e.target;
    if(alvo.tagName==='BUTTON'){
        const botao = alvo;
        const id = botao.dataset.id;
        try{
            if(botao.textContent.trim() === '[EDITAR]') {

                await preencherHtml('formAlterar.html', document.querySelector('#form-usuarios'));
                //formUsuario = document.querySelector("#form-usuarios");
                let usuario = await obter(id);
                document.querySelector("#id").value = usuario.id;
                document.querySelector("#nome").value = usuario.nome;
                /*document.querySelector("#login").value = ""; 
                document.querySelector("#senha").value = ""; 
                document.querySelector("#senha2").value = ""; 
                document.querySelector("#login").disabled = true;
                document.querySelector("#senha").disabled = true;
                document.querySelector("#senha2").disabled = true;*/
            }else{ 
                if(botao.textContent.trim() === '[EXCLUIR]'){
                    let erro = await remover(id);
                    if( ! erro ){ //Se removeu, lista os registros novamente
                        let registros = await listar();
                        montarTabela(registros);
                    }
                }
            }
        }catch( e ){//4xx/5xx
            exibirErro( spanErro , '('+e.status+') '+e, 3000);
        }
    }
})

//Funções auxiliares para montagem do DOM
function montarTabela(registros){
    preencherHtml('formInserir.html', document.querySelector('#form-usuarios'));

    const corpoTabela = document.querySelector("#tbl-usuarios tbody");
    while(corpoTabela.firstChild)
        corpoTabela.removeChild(corpoTabela.firstChild);
    
    registros.forEach(registro => {
        const linha = montaLinha(registro); 
        corpoTabela.appendChild(linha);   
    });
}

function montaLinha({id, nome}){
    let tr = document.createElement('tr');
    const celulas = [id,nome].map(texto => {
        const td = document.createElement('td');
        td.textContent = texto;
        return td;
    })
    const btnEditar = criaBotao('[EDITAR]', id);
    const btnExcluir = criaBotao('[EXCLUIR]', id);
    const tdAcoes = document.createElement('td');
    tdAcoes.append(btnEditar, btnExcluir);
    tr.append(...celulas, tdAcoes);
    return tr;
}

function criaBotao(rotulo, valorId){
    const botao = document.createElement('button');
    botao.textContent = rotulo;
    botao.dataset.id = valorId;
    return botao;
}