import { requisicao, ROOT } from "../util.js";
// Agora o base da API independe de onde o projeto está instalado
const API_BASE = `${ROOT}/api/usuarios`;
const API_LOGAR = `${ROOT}api/usuarios-logar`;
//Todos os métodos deixam Error passar para gestor.js
export async function listar(){
    let resposta = await requisicao('GET',API_BASE);
    return await resposta.json();
} 

export async function logar(usuario){
    let resposta = await requisicao('POST',API_LOGAR, usuario);
    return await resposta.json();
}

export async function salvar(usuario){
    let resposta = null;
    const id = Number(usuario.id);
    if(!id>0){
        console.log(usuario);
        resposta = await requisicao('POST',API_BASE, usuario);
    }else{
        console.log(usuario);
        resposta = await requisicao('PUT',API_BASE, usuario);
    }      
    return await resposta.json();
}

export async function obter(id){
    let resposta = await requisicao('GET',`${API_BASE}/${id}`);
    return await resposta.json();
}

export async function remover(id){
    await requisicao('DELETE',`${API_BASE}/${id}`);
}