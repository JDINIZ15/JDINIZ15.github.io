import { logar } from "./usuarios/requisicoes.js";
import { exibirErro, preencherHtml } from "./util.js";
const spanErro = document.querySelector('#msgErro');

document.addEventListener('DOMContentLoaded',async ()=>{
    //Requisição para autenticar.php
    let resposta = await fetch('api/autenticar.php')
    //se voltar 401 (carrega formLogar) else esvazia o main
    await preencherHtml('formLogar.html', document.querySelector('#div-modal'));
    const formLogar = document.querySelector('#form-logar');    
    if(!resposta.ok && resposta.status===401){
        document.querySelector('.meuModal').showModal(); 
    }

    //Quando precisar logar...
    formLogar.addEventListener('submit', async evento=>{
        evento.preventDefault();
        let usuario = {
            "login":document.querySelector('#login').value,
            "senha":document.querySelector('#senha').value
        }; 

        try{
            await logar(usuario);
            formLogar.reset();
            document.querySelector('.meuModal').close();
        }catch( e ){//4xx/5xx
            document.querySelector('.meuModal').close();
            exibirErro( spanErro , '('+e.status+') '+e, 3000);
        }
    })
})



//Falta bd e api

