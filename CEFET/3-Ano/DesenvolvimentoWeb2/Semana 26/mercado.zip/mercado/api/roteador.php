<?php
declare(strict_types=1);
require_once __DIR__ . '/util/httpUtil.php';
require_once __DIR__ . '/util/bDUtil.php';
require_once __DIR__ . '/vendor/autoload.php';

$pdo = getConexao();
[$uri, $logica, $metodo] = processaRequisicao($_SERVER);
//Aqui só precisamos saber a lógica
if( $logica === 'usuarios-logar')
    require_once 'src/rotas/rotasUsuario.php';
else
    require_once 'autenticar.php';
switch( $logica ){
    case 'generos':require_once 'src/rotas/rotasGenero.php';break;
    case 'produtos':require_once 'src/rotas/rotasProduto.php';break;
    case 'usuarios':require_once 'src/rotas/rotasUsuario.php';break;
    default:responder(404, 'Rota não encontrada');
}

