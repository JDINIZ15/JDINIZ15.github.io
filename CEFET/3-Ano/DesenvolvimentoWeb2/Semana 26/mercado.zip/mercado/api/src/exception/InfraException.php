<?php
declare(strict_types=1);
class InfraException extends DominioException{}