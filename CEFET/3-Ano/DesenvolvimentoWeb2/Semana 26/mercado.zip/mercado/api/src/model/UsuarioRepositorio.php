<?php
declare(strict_types=1);

/** @author Rafael Guimarães Rodrigues */
interface UsuarioRepositorio{
    /**
     * Retorna um array com id e nome do usuário logado
     * @param array $usuario array com informações do usuário para logar
     * @return array array com id e nome do usuario logado
     */
    public function logar( array $usuario ):array;
    /**
     * Retorna todos os usuarios
     * @return array array com todas as linhas da tabela
     */
    public function todos():array;

    /**
     * Remove um udsuario pelo id
     * @return int linhas afetadas
     */
    public function removerPeloId( int $id ):int;

    /**
     * Insere um usuario
     * @param Usuario $usuario com o usuario a ser inserido
     * @return int último id gerado
     */
    public function inserir( Usuario $usuario ):int;

    /**
     * Altera um usuario
     * @param array $usuario com alguns dados do usuario a ser alterado
     * @return int linhas afetadas
     */
    public function alterar( array $usuario ):int;

    /**
     * Obtém um usuario pelo id
     * @param int $id 
     * @return array array com as informações um objeto do tipo Usuario
     */
    public function obterPeloId( int $id ): array;

    /**
     * Obtém o id de um usuario pelo nome
     * @param string $nome 
     * @return int id do usuario encontrado ou -1, se não
     */
    public function obterIdPeloNome( string $nome ): int;

    /**
     * Obtém o id de um usuario pelo login
     * @param string $login 
     * @return int id do usuario encontrado ou -1, se não
     */
    function obterIdPeloLogin(string $login):int;
}