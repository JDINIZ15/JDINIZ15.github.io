<?php
declare(strict_types=1);
class ParametrosInvalidosException extends DominioException{}