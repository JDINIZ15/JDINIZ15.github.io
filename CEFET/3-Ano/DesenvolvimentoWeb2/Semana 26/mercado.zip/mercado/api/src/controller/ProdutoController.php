<?php
declare(strict_types=1);

class ProdutoController{
    public function __construct( private ProdutoRepositorio $repositorio
    , private GeneroRepositorioEmBDR $repositorioGenero)
    {}

    public function todos():array{
            return $this->repositorio->todos();
    }

    public function inserir( Produto $produto ):int{
        $genero = $this->repositorioGenero->obterPeloId( $produto->getGenero()->getId());
        $genero = Genero::fromArray($genero);
        if( $genero === null )
            throw new NaoEncontradoException('Genero não encontrado', 400);
        return $this->repositorio->inserir( $produto );     
    }

    public function alterar( Produto $produto):int{  
        $genero = $this->repositorioGenero->obterPeloId( $produto->getGenero()->getId());
        $genero = Genero::fromArray($genero);
        if( $genero === null )
            throw new NaoEncontradoException('Genero não encontrado', 400);

        $problemas = $produto->validar();
        if( !empty( $problemas ))
            throw new ParametrosInvalidosException( $problemas, 400);

        $encontrado = $this->obterPeloId( $produto->getId() );
        if( $encontrado === null )
            throw new NaoEncontradoException('Produto não encontrado para atualização', 400);
        
        return $this->repositorio->alterar( $produto );
    }

    public function obterPeloId( int $id ):array{
        return $this->repositorio->obterPeloId ( $id );
    }

    public function removerPeloId( int $id ):void{
        $encontrado = $this->obterPeloId( $id );
        if( $encontrado === null )
            throw new NaoEncontradoException('Produto não encontrado para remoção', 400);
        $this->repositorio->removerPeloId( $id );
    }
}