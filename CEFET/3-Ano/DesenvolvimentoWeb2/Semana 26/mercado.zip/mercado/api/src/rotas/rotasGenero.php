<?php
declare(strict_types=1);

//Aqui só precisamos saber a uri (generos ou generos/id)
//e o método (GET,POST,PUT,DELETE)
//Os parâmetros virão sempre no POST ou PUT e no DELETE via $_GET
$controller = new GeneroController( new GeneroRepositorioEmBDR( $pdo ) );

if ($uri === 'generos' ){
    
    switch( $metodo ){
        case 'GET': try{
                        $registros = $controller->todos();
                        responder(200, $registros);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }
                    break;
        case 'POST': $in = json_decode(file_get_contents('php://input'),true);
                     // Higienização básica (só ajusta formato, sem regra de negócio)
                        $in = ['descricao' => isset($in['descricao']) ? trim($in['descricao']) : ''];
                        $genero = new Genero(0, $in['descricao']);
                        try{
                            if( $controller->inserir( $genero ) > 0 )
                            responder( 201, ['Registro inserido com sucesso'] );
                        else
                            responder( 400, ['Nenhum registro foi inserido'] );
                        }catch(DominioException $e){
                            responder($e->getCode(), $e->getMessage());
                        }catch(\Exception $e){
                            responder($e->getCode(), $e->getMessage());
                        }                 
                        break;       
        case 'PUT':  $in = json_decode(file_get_contents('php://input'),true);
                        // Higienização básica (só ajusta formato, sem regra de negócio)
                        $in = [
                        'descricao' => isset($in['descricao']) ? trim($in['descricao']) : '',
                        'id'        => isset($in['id']) ? (int) trim($in['id']) : 0
                    ];
                    $genero = new Genero(intval( $in['id'] ), $in['descricao']);
                    try{
                        if( $controller->alterar( $genero ) > 0 )
                            responder( 200, ['Registro alterado com sucesso'] );
                        else
                            responder( 400, ['Nenhum registro foi alterado'] );
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }
                    break;
    }
    //Sinaliza p/ o cliente os métodos aceitos
    header('Allow: GET, POST, PUT'); 
    http_response_code(405); 
    die( json_encode(['Método não permitido']) );

}
    
//Aqui $uri vai ser generos/{id}
//Não aceita nada antes de generos. 
//Só aceita números depois de generos e guarda em $paramtros[1]
if (preg_match('#^generos/([0-9]+)/?$#', $uri, $parametros)===1){
    $_GET['id'] = (int)$parametros[1]; // disponibiliza para os controllers
    switch( $metodo ){
        case 'GET': $in = $_GET; 
                    try{
                        $registro = $controller->obterPeloId( intval($in['id']) );
                        responder(200, $registro);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }      
                    break;
        case 'DELETE':$in = $_GET;
                    try{
                        $controller->removerPeloId( intval($in['id']) );
                        responder(204);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }  
                    break;
    }
    header('Allow: GET, DELETE'); 
    http_response_code(405); 
    die( json_encode(['Método não permitido']) );
}
    
?>