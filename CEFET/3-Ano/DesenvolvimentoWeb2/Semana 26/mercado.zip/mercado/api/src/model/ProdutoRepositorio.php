<?php
declare(strict_types=1);

/** @author Rafael Guimarães Rodrigues */
interface ProdutoRepositorio{
    /**
     * Retorna todos os produtos
     * @return array array com todas as linhas da tabela
     */
    public function todos():array;

    /**
     * Remove um produto pelo id
     * @return int linhas afetadas
     */
    public function removerPeloId( int $id ):int;

    /**
     * Insere um produto
     * @param Produto $produto com o genero a ser inserido
     * @return int último id gerado
     */
    public function inserir( Produto $produto ):int;

    /**
     * Altera um produto
     * @param Produto $produto com o genero a ser alterado
     * @return int linhas afetadas
     */
    public function alterar( Produto $produto ):int;

    /**
     * Obtém um produto pelo id
     * @param int $id 
     * @return array array com as informações um objeto do tipo Produto
     */
    public function obterPeloId( int $id ): array;

    /**
     * Obtém o id de um produto pela descrição
     * @param string $descricao 
     * @return int id do produto encontrado ou -1, se não
     */
    public function obterIdPelaDescricao( string $descricao ): int;
}