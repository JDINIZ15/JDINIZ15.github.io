<?php
declare(strict_types=1);
class IntegridadeException extends DominioException{}