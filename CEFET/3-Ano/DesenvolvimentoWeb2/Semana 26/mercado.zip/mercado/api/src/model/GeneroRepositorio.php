<?php
declare(strict_types=1);

/** @author Rafael Guimarães Rodrigues */
interface GeneroRepositorio{
    /**
     * Retorna todos os generos
     * @return array array com todas as linhas da tabela
     */
    public function todos():array;

    /**
     * Remove um genero pelo id
     * @return int linhas afetadas
     */
    public function removerPeloId( int $id ):int;

    /**
     * Insere um genero
     * @param Genero $genero com o genero a ser inserido
     * @return int último id gerado
     */
    public function inserir( Genero $genero ):int;

    /**
     * Altera um genero
     * @param Genero $genero com o genero a ser alterado
     * @return int linhas afetadas
     */
    public function alterar( Genero $genero ):int;

    /**
     * Obtém um genero pelo id
     * @param int $id 
     * @return array array com as informações um objeto do tipo Genero
     */
    public function obterPeloId( int $id ): array;

    /**
     * Obtém o id de um genero pela descrição
     * @param string $descricao 
     * @return int id do genero encontrado ou -1, se não
     */
    public function obterIdPelaDescricao( string $descricao ): int;
}