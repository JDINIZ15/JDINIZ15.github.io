<?php
declare(strict_types=1);
//namespace cefet\projetobase\exception;
class ConflitoException extends DominioException{}