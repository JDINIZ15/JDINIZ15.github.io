<?php
declare(strict_types=1);

class ProdutoRepositorioEmBDR implements ProdutoRepositorio{
    protected PDO $pdo;

    public function __construct( PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    function todos():array{
         $linhas = [];
        try{
            $sql = <<<SQL
                SELECT p.id, p.descricao, g.descricao as descGenero
                , p.preco_de_custo as precoDeCusto, p.genero_id as generoId
                , ROUND( (p.preco_de_custo * 1.3), 2 ) as precoDeVenda
                FROM produto p JOIN genero g ON(p.genero_id = g.id)
            SQL;
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $linhas = $stmt->fetchAll();
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registros. {$e->getMessage()}", 500);
        }
        return $linhas;
    }

    function removerPeloId( int $id ): int{
       try{
            $sql = <<<SQL
                DELETE FROM produto WHERE id = :ID
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $stmt->bindParam(':ID', $id);
            $stmt->execute();
            return $stmt->rowCount();
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new ConflitoException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
            throw new InfraException("Erro do servidor ao remover registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function inserir( Produto $produto ):int{
        try{
            $sql = <<<SQL
                INSERT INTO produto(descricao, preco_de_custo, genero_id) 
                VALUES(:DESC, :PCUSTO, :GENID)
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $descricao = $produto->getDescricao();
            $precoDeCusto = $produto->getPrecoDeCusto();
            $idGenero = $produto->getGenero()->getId();
            $stmt->bindParam(':DESC', $descricao);
            $stmt->bindParam(':PCUSTO', $precoDeCusto);
            $stmt->bindParam(':GENID', $idGenero);
            $stmt->execute();
            return intval($this->pdo->lastInsertId());
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new IntegridadeException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
                else    
                    throw new ConflitoException("Conflito. Registro já existe. {$e->getMessage()}", 409);
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function alterar( Produto $produto ):int{
        try{
            $sql = <<<SQL
                UPDATE produto SET descricao = :DESC
                , preco_de_custo = :PCUSTO, genero_id = :GENID 
                WHERE id = :ID
            SQL; 
            $stmt = $this->pdo->prepare( $sql );
            $stmt->bindValue(':DESC', $produto->getDescricao());
            $stmt->bindValue(':PCUSTO', $produto->getPrecoDeCusto());
            $stmt->bindValue(':GENID', $produto->getGenero()->getId());
            $stmt->bindValue(':ID', $produto->getId());
            $stmt->execute();
            return $stmt->rowCount();
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new IntegridadeException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
                else    
                    throw new ConflitoException("Conflito. Registro já existe. {$e->getMessage()}", 409);
            throw new InfraException("Erro ao alterar registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function obterPeloId( int $id ):array{
        $linha = [];
        try{
            $sql = <<<SQL
                SELECT id, descricao, preco_de_custo as precoDeCusto, genero_id as generoId 
                FROM produto WHERE id = ?
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $linha = $stmt->fetch();
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return $linha;
    }

    function obterIdPelaDescricao(string $descricao):int{
        try{
            $sql = <<<SQL
                SELECT id, descricao, preco_de_custo as precoDeCusto, genero_id as generoId 
                FROM produto WHERE descricao = :DESC
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':DESC', $descricao, PDO::PARAM_STR);
            $stmt->execute();
            $linha = $stmt->fetch();
            if( $stmt->rowCount() > 0 )
                return $linha['id'];
            return -1;
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }
}