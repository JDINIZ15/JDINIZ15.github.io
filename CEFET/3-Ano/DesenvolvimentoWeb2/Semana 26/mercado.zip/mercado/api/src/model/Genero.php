<?php
declare(strict_types=1);

class Genero{
    public function __construct(
        private int $id=0
        , private string $descricao
    ){}

    /**
     * Retorna os problemas com o gênero
     * @return string mensagens de erro concatenadas
     */
    public function validar():string{
        $problemas = "";
        //id
        if( $this->id === null )
            $problemas .= 'O id deve ser fornecido.';
        else if( ! ($this->id !== null && is_numeric( $this->id ) && $this->id >= 0) )
            $problemas .= 'O id deve ser numérico e não negativo.';
        //descricao
        if( mb_strlen($this->descricao,'UTF-8') < 3 || mb_strlen($this->descricao,'UTF-8') >20 )
            $problemas .= "<br/>A descrição deve ter entre 3 e 20 caracteres.";

        return $problemas;
    }

    public function getId():int{
        return $this->id;
    }

    public function getDescricao():string{
        return $this->descricao;
    }

    public function comoArray():array{
        return get_object_vars( $this );
    }

    public static function fromArray(array $genero):Genero{
        return new Genero($genero['id'],$genero['descricao']);
    } 
}