<?php
declare(strict_types=1);
/**
 * Exceção de domínio
 * @author Rafael Guimarães Rodrigues
 */
class DominioException extends \RuntimeException{
    function __construct(string $msg, int $codigo)
    {
        parent::__construct($msg, $codigo);
    }
}