<?php
declare(strict_types=1);
class UsuarioRepositorioEmBDR implements UsuarioRepositorio{
    protected PDO $pdo;

    public function __construct( PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function logar( array $usuario ):array{
    $dados = [];
        try {
            $sql = "SELECT id,nome,senha FROM usuario WHERE login=? ";
            $stmt = $this->pdo->prepare($sql);
            // Gera o hash seguro da senha (BCrypt/Argon, dependendo da versão)
            $stmt->bindParam(1, $usuario['login']);
            $stmt->execute();
            if($stmt->rowCount()>0 ){
                $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $dados = $dados[0];
                if(password_verify($usuario['senha'], $dados['senha'])){
                    unset($dados['senha']);
                    return $dados;
                }    
            }
        }catch(PDOException $e){
            throw new NaoEncontradoException( "Não foi possível logar. {$e->getMessage()}", 400, $e );
        }
        return [];    
    }

    function todos():array{
       $linhas = [];
        try{
            $sql = <<<SQL
                SELECT id, nome FROM usuario
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $linhas = $stmt->fetchAll();
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registros. {$e->getMessage()}", 500);
        }
        return $linhas;
    }

    function removerPeloId( int $id ): int{
        try{
            $sql = <<<SQL
                DELETE FROM usuario WHERE id = :ID
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $stmt->bindValue(':ID', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->rowCount();
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new ConflitoException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
            throw new InfraException("Erro do servidor ao remover registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function inserir( Usuario $usuario ):int{
         try{
            $sql = <<<SQL
                INSERT INTO usuario(nome, login, senha) VALUES(:NOME, :LOGIN, :SENHA)
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $stmt->bindValue(':NOME', $usuario->getNome(), PDO::PARAM_STR);
            $stmt->bindValue(':LOGIN', $usuario->getLogin(), PDO::PARAM_STR);
            // Gera o hash seguro da senha (BCrypt/Argon, dependendo da versão)
            $senhaHash = password_hash($usuario->getSenha(), PASSWORD_DEFAULT);
            
            $stmt->bindValue(':SENHA', $senhaHash );
            $stmt->execute();
            return intval($this->pdo->lastInsertId());
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new IntegridadeException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
                else    
                    throw new ConflitoException("Conflito. Registro já existe. {$e->getMessage()}", 409);
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function alterar( array $usuario ):int{
         try{
            $sql = <<<SQL
                UPDATE usuario SET nome = :NOME WHERE id = :ID
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $stmt->bindValue(':NOME', $usuario['nome'], PDO::PARAM_STR);
            $stmt->bindValue(':ID', intval($usuario['id']), PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->rowCount();
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new IntegridadeException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
                else    
                    throw new ConflitoException("Conflito. Registro já existe. {$e->getMessage()}", 409);
            throw new InfraException("Erro ao alterar registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function obterPeloId( int $id ):array{
         $linha = [];
        try{
            $sql = <<<SQL
                SELECT id, nome FROM usuario WHERE id = ?
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id, PDO::PARAM_INT);
            $stmt->execute();
            $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return $linha;
    }

    function obterIdPeloNome(string $nome):int{
        try{
            $sql = <<<SQL
                SELECT id, nome, login FROM usuario WHERE nome = :NOME
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':NOME', $nome, PDO::PARAM_STR);
            $stmt->execute();
            $linha = $stmt->fetch();
            if( $stmt->rowCount() > 0 )
                return $linha['id'];
            return -1;
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

        function obterIdPeloLogin(string $login):int{
        try{
            $sql = <<<SQL
                SELECT id, nome, login FROM usuario WHERE login = :LOGIN
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':LOGIN', $login, PDO::PARAM_STR);
            $stmt->execute();
            $linha = $stmt->fetch();
            if( $stmt->rowCount() > 0 )
                return $linha['id'];
            return -1;
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }
}