<?php
declare(strict_types=1);

//Aqui só precisamos saber a uri (produtos ou produtos/id)
//e o método (GET,POST,PUT,DELETE)
//Os parâmetros virão sempre no POST ou PUT e no DELETE via $_GET
$controller = new ProdutoController( new ProdutoRepositorioEmBDR( $pdo ), new GeneroRepositorioEmBDR( $pdo) );
$controllerGenero = new GeneroController( new GeneroRepositorioEmBDR( $pdo ) );
if ($uri === 'produtos')
    switch( $metodo ){
        case 'GET': case 'GET': try{
                        $registros = $controller->todos();
                        responder(200, $registros);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }
                    break;
        case 'POST':$in = json_decode(file_get_contents('php://input'),true);
                    // Higienização básica (só ajusta formato, sem regra de negócio)
                    $in = [
                        'descricao'     => isset($in['descricao']) ? trim($in['descricao']) : '',
                        'id'            => 0,
                        'precoDeCusto'  => isset($in['precoDeCusto']) ? (float) $in['precoDeCusto'] : 0.0,
                        'generoId'      => isset($in['generoId']) ? (int) $in['generoId'] : 0,
                    ];
                    $genero = $controllerGenero->obterPeloId( $in['generoId'] ); 
                    $genero = Genero::fromArray($genero);
                    $produto = new Produto($in['id'], $in['descricao'], $in['precoDeCusto'], $genero);
                    try{
                        if( $controller->inserir( $produto ) > 0 )
                        responder( 201, ['Registro inserido com sucesso'] );
                    else
                        responder( 400, ['Nenhum registro foi inserido'] );
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }                 
                    break;       
        case 'PUT': $in = json_decode(file_get_contents('php://input'),true);
                    // Higienização básica (só ajusta formato, sem regra de negócio)
                    $in = [
                        'descricao'     => isset($in['descricao']) ? trim($in['descricao']) : '',
                        'id'            => isset($in['id']) ? (int) $in['id'] : 0,
                        'precoDeCusto'  => isset($in['precoDeCusto']) ? (float) $in['precoDeCusto'] : 0.0,
                        'generoId'      => isset($in['generoId']) ? (int) $in['generoId'] : 0,
                    ];
                    $genero = $controllerGenero->obterPeloId( $in['generoId'] );
                    $genero = Genero::fromArray($genero);
                    $produto = new Produto($in['id'], $in['descricao'], $in['precoDeCusto'], $genero);
                    try{
                        if( $controller->alterar( $produto ) > 0 )
                            responder( 200, ['Registro alterado com sucesso'] );
                        else
                            responder( 400, ['Nenhum registro foi alterado'] );
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }
                    break;
    }

//produtos/{id}
//Não aceita nada antes de produtos. 
//Só aceita números depois de produtos e guarda em $paramtros[1]
if (preg_match('#^produtos/([0-9]+)/?$#', $uri, $parametros)===1){
    $_GET['id'] = (int)$parametros[1]; // disponibiliza para os controllers
    switch( $metodo ){
        case 'GET': $in = $_GET; 
                    try{
                        $registro = $controller->obterPeloId( intval($in['id']) );
                        responder(200, $registro);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }      
                    break;
        case 'DELETE':$in = $_GET;
                    try{
                        $controller->removerPeloId( intval($in['id']) );
                        responder(204);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }  
                    break;
    }
}
    
?>