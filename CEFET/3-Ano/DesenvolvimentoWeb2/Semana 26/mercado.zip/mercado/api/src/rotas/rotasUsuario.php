<?php
//declare(strict_types=1);

//Aqui só precisamos saber a uri (usuarios ou usuarios/id)
//e o método (GET,POST,PUT,DELETE)
//Os parâmetros virão sempre no PUT e no DELETE via $_GET

$controller = new UsuarioController( new UsuarioRepositorioEmBDR( $pdo ) );
if($uri === 'usuarios-logar' && $metodo === 'POST'){
    $input = json_decode(file_get_contents('php://input'),true);
    // Higienização básica (só ajusta formato, sem regra de negócio)
    $usuario = [
        'login'     => isset($input['login']) ? trim($input['login']) : '',
        'senha'     => isset($input['senha']) ? trim($input['senha']) : '',
    ];
    try{
        $controller->logar( $usuario );
        $registro = $controller->logar( $usuario );
        if( $registro !== null && session_status() === PHP_SESSION_NONE){
            session_start();
            $_SESSION['usuario'] = $registro['nome'];
            $_SESSION['usuario_id'] = $registro['id'];
            $_SESSION['ultima-atividade'] = time();
        }
        responder(200, ['Usuário logado com sucesso!']);
    }catch(DominioException $e){
        responder($e->getCode(), $e->getMessage());
    }catch(Exception $e){
        responder($e->getCode(), $e->getMessage());
    }
}

if($uri === 'usuarios' ){
    
    switch( $metodo ){
        case 'GET': try{
                        $registros = $controller->todos();
                        responder(200, $registros);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }
                    break;
        case 'POST':$in = json_decode(file_get_contents('php://input'),true); 
                    $in = [
                        'nome' => isset($in['nome']) ? trim($in['nome']) : '',
                        'login' => isset($in['login']) ? trim($in['login']) : '',
                        'senha' => isset($in['senha']) ? trim($in['senha']) : '',
                        'senha2' => isset($in['senha2']) ? trim($in['senha2']) : ''
                     ];
                     $usuario = new Usuario( 0, $in['nome'], $in['login'], $in['senha'], $in['senha2']);
                     try{
                        if( $controller->inserir( $usuario ) > 0 )
                        responder( 201, ['Registro inserido com sucesso'] );
                    else
                        responder( 400, ['Nenhum registro foi inserido'] );
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    } 
                    break;       
        case 'PUT': $in = json_decode(file_get_contents('php://input'),true);
                    // Higienização básica (só ajusta formato, sem regra de negócio)
                    $in = [
                        'nome' => isset($in['nome']) ? trim($in['nome']) : '',
                        'id'        => isset($in['id']) ? (int) $in['id'] : 0
                    ];
                    try{
                        if( $controller->alterar( $in ) > 0 )
                            responder( 200, ['Registro alterado com sucesso'] );
                        else
                            responder( 400, ['Nenhum registro foi alterado'] );
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    } 
                    break;
    }
    //Sinaliza p/ o cliente os métodos aceitos
    header('Allow: GET, POST, PUT'); 
    http_response_code(405); 
    die( json_encode(['Método não permitido']) );

}
    
//Aqui $uri vai ser usuarios/{id}
//Não aceita nada antes de usuarios. 
//Só aceita números depois de usuarios e guarda em $paramtros[1]
if (preg_match('#^usuarios/([0-9]+)/?$#', $uri, $parametros)===1){
    $_GET['id'] = (int)$parametros[1]; // disponibiliza para os controllers
    switch( $metodo ){
        case 'GET': $in = $_GET;
                    // Higienização básica (só ajusta formato, sem regra de negócio)
                    $in = ['id' => isset($in['id']) ? (int) trim($in['id']) : 0]; 
                    try{
                        $registro = $controller->obterPeloId( intval($in['id']) );
                        responder(200, $registro);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }      
                    break;
        case 'DELETE':$in = $_GET;
                    try{
                        $controller->removerPeloId( intval($in['id']) );
                        responder(204);
                    }catch(DominioException $e){
                        responder($e->getCode(), $e->getMessage());
                    }catch(\Exception $e){
                        responder($e->getCode(), $e->getMessage());
                    }  
                    break;
    }
    header('Allow: GET, DELETE'); 
    http_response_code(405); 
    die( json_encode(['Método não permitido']) );
}
?>