<?php
declare(strict_types=1);

class GeneroRepositorioEmBDR implements GeneroRepositorio{
    protected PDO $pdo;

    public function __construct( PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    function todos():array{
        $linhas = [];
        try{
            $sql = <<<SQL
                SELECT id, descricao FROM genero
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $linhas = $stmt->fetchAll();
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registros. {$e->getMessage()}", 500);
        }
        return $linhas;
    }

    function removerPeloId( int $id ): int{
        try{
            $sql = <<<SQL
                DELETE FROM genero WHERE id = :ID
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $stmt->bindParam(':ID', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->rowCount();
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new ConflitoException("Problema de integridade. Registro $id possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
            throw new InfraException("Erro do servidor ao remover registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function inserir( Genero $genero ):int{
        try{
            $sql = <<<SQL
                INSERT INTO genero(descricao) VALUES(:DESC)
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $descricao = $genero->getDescricao();
            $stmt->bindParam(':DESC',$descricao, PDO::PARAM_STR);
            $stmt->execute();
            return intval($this->pdo->lastInsertId());
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new IntegridadeException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
                else    
                    throw new ConflitoException("Conflito. Registro já existe. {$e->getMessage()}", 409);
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function alterar( Genero $genero ):int{
        try{
            $sql = <<<SQL
                UPDATE genero SET descricao = :DESC WHERE id = :ID
            SQL;
            $stmt = $this->pdo->prepare( $sql );
            $descricao = $genero->getDescricao();
            $stmt->bindParam(':DESC', $descricao, PDO::PARAM_STR);
            $id = $genero->getId();
            $stmt->bindParam(':ID', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->rowCount();
        }catch(PDOException $e){
            if( $e->getCode() === '23000')
                if((int)$e->errorInfo[1] === 1451 || (int)$e->errorInfo[1] === 1452)
                    throw new IntegridadeException("Problema de integridade. Registro possui associação com outro(s) registro(s). {$e->getMessage()}", 409);
                else    
                    throw new ConflitoException("Conflito. Registro já existe. {$e->getMessage()}", 409);
            throw new InfraException("Erro ao alterar registro. {$e->getMessage()}", 500);
        }
        return 0;
    }

    function obterPeloId( int $id ):array{
        $linha = [];
        try{
            $sql = <<<SQL
                SELECT id, descricao FROM genero WHERE id = ?
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(1, $id, PDO::PARAM_INT);
            $stmt->execute();
            $linha = $stmt->fetch();
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return $linha;
    }

    function obterIdPelaDescricao(string $descricao):int{
        try{
            $sql = <<<SQL
                SELECT id, descricao FROM genero WHERE descricao = :DESC
            SQL;
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':DESC', $descricao, PDO::PARAM_STR);
            $stmt->execute();
            $linha = $stmt->fetch();
            if( $stmt->rowCount() > 0 )
                return $linha['id'];
            return -1;
        }catch(PDOException $e){
            throw new InfraException("Erro do servidor ao obter registro. {$e->getMessage()}", 500);
        }
        return 0;
    }
}