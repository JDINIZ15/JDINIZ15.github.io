<?php
declare(strict_types=1);

class Usuario{
    public function __construct(
        private int $id=0,
        private string $nome = '',
        private string $login = '',
        private string $senha = '',
        private string $senhaConfirmacao = ''
    )
    {}

    public function getId():int{
        return $this->id;
    }
    public function getNome():string{
        return $this->nome;
    }

    public function getLogin():string{
        return $this->login;
    }

    public function getSenha():string{
        return $this->senha;
    }

    /**
     * Retorna problemas com o usuário
     * @return string mensagens de erro concatenadas
     */
    public function validar():string{
        $problemas = "";

        if( $this->id === null )
            $problemas .= 'O id deve ser fornecido.';
        else if( ! ($this->id !== null && is_numeric( $this->id ) && $this->id >= 0) )
            $problemas .= 'O id deve ser numérico e não negativo.';

        if( mb_strlen($this->nome,'UTF-8') < 3 || mb_strlen($this->nome,'UTF-8') >20 )
            $problemas .= "<br/>O nome deve ter entre 3 e 20 caracteres.";

        if( mb_strlen($this->login,'UTF-8') < 5 )
            $problemas .= '<br/>Login deve ter ao menos 5 caracteres';

        if( mb_strlen($this->senha,'UTF-8') < 4 || mb_strlen($this->senha,'UTF-8') >6 )
        $problemas .= '<br/>Senha deve ter entre 4 e 6 caracteres';

        if( $this->senha !== $this->senhaConfirmacao )
            $problemas .= '<br/>A senha e a confirmação precisam ser iguais.';

        return $problemas;
    }

    public static function validarAlteracao( array $usuario):string{
        $problemas = "";

        if( $usuario['id'] === null )
            $problemas .= 'O id deve ser fornecido.';
        else if( ! ($usuario['id'] !== null && is_numeric( $usuario['id'] ) && intval($usuario['id']) >= 0) )
            $problemas .= 'O id deve ser numérico e não negativo.';

        //echo "Nome: {$usuario['nome']}<hr/>";
        if( mb_strlen($usuario['nome'],'UTF-8') < 3 || mb_strlen($usuario['nome'],'UTF-8') >20 )
            $problemas .= "<br/>O nome deve ter entre 3 e 20 caracteres.";

        return $problemas;
    }

    public function comoArray():array{
        return get_object_vars( $this );
    }
}