<?php
declare(strict_types=1);

/**
 * Exceção de entrada inválida
 * @author Rafael Guimarães Rodrigues
 */
class EntradaInvalidaException extends DominioException{

    protected array $problemas = [];

    /**
     * Cria um array com um conjunto de problemas
     * @param array<string> $problemas
     * @return EntradaInvalidaException 
     */

    public static function comProblemas( array $problemas ):self{
        return ( new EntradaInvalidaException('Problemas de validação', 400) )->setProblemas( $problemas );
    }

    /**
     * Preenche os problemas para exibir em lista
     * @param array<string> $problemas mensagens de validação
     * @return EntradaInvalidaException
     */
    public function setProblemas( array $problemas ):self{
        $this->problemas = $problemas;
        return $this;
    }

    public function getProblemas():array{
        return $this->problemas;
    }
}