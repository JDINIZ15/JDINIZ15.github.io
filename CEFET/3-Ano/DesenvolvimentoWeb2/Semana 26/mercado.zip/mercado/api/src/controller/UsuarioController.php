<?php
declare(strict_types=1);

class UsuarioController{
    public function __construct( private UsuarioRepositorio $repositorio)
    {}

    public function logar( array $usuario ):array{
            return $this->repositorio->logar( $usuario );
    }

    public function todos():array{
        return $this->repositorio->todos();
    }

    public function inserir( Usuario $usuario):int{
        $problemas = $usuario->validar();
        if( !empty( $problemas ))
            throw new ParametrosInvalidosException( $problemas, 400);
        return $this->repositorio->inserir( $usuario ); 
    }

    public function alterar( array $usuario ):int{
        $problemas = Usuario::validarAlteracao( $usuario );
        if( !empty( $problemas ))
            throw new ParametrosInvalidosException( $problemas, 400);

        $encontrado = $this->obterPeloId( intval($usuario['id']) );
        if( $encontrado === null )
            throw new NaoEncontradoException('Usuário não encontrado para atualização', 400);
        return $this->repositorio->alterar( $usuario );   
    }

    public function obterPeloId( int $id ):array{
        $encontrado = $this->repositorio->obterPeloId( $id );
        if( $encontrado === null )
            throw new NaoEncontradoException('Usuário não encontrado para remoção', 400);
        return $encontrado;
    }

    public function removerPeloId( int $id ):int{
        $encontrado = $this->repositorio->obterPeloId( $id );
        if( $encontrado === null )
            throw new NaoEncontradoException('Usuário não encontrado para remoção', 400);
        return $this->repositorio->removerPeloId( $id );
    }
}