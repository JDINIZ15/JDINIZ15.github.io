<?php
declare(strict_types=1);

class Produto{
    public function __construct(
        private int $id=0,
        private string $descricao = '',
        private float $precoDeCusto = 0.0,
        private Genero|null|int $genero =null
    ){}

    public function getId():int{
        return $this->id;
    }
    
    public function getDescricao():string{
        return $this->descricao;
    }

    public function getPrecoDeCusto():float{
        return $this->precoDeCusto;
    }

    public function getGenero():Genero{
        return $this->genero;
    }

    /**
     * Retorna problemas com o produto
     * @return string mensagens de erro concatenadas
     */
    public function validar():string{
        $problemas = "";

        if( $this->id === null )
            $problemas .= 'O id deve ser fornecido.';
        else if( ! ($this->id !== null && is_numeric( $this->id ) && $this->id >= 0) )
            $problemas .= 'O id deve ser numérico e não negativo.';

        if( mb_strlen($this->descricao,'UTF-8') < 3 || mb_strlen($this->descricao,'UTF-8') >20 )
            $problemas .= "<br/>A descrição deve ter entre 3 e 20 caracteres.";

        if( $this->precoDeCusto <=0 )
            $problemas .= '<br/>O preço de custo deve ser positivo e maior do que zero.';

        if( $this->genero->getId() === null || $this->genero->getId() <= 0 )
            $problemas .= '<br/>O gênero do produto deve ser definido.';

        return $problemas;
    }

    public function comoArray():array{
        return get_object_vars( $this );
    }

}

