<?php
declare(strict_types=1);

class GeneroController{
    private GeneroRepositorio $repositorio;
    public function __construct( GeneroRepositorioEmBDR $repositorio)
    {
        $this->repositorio = $repositorio;
    }

    public function todos():array{
        return $this->repositorio->todos();
    }

    public function inserir( Genero $genero):int{
        $problemas = $genero->validar();
        if( !empty( $problemas ))
            throw new ParametrosInvalidosException( $problemas, 400);
        return $this->repositorio->inserir( $genero );
    }

    public function alterar( Genero $genero):int{ 
        $problemas = $genero->validar();
        if( !empty( $problemas ))
            throw new ParametrosInvalidosException( $problemas, 400);

        $encontrado = $this->obterPeloId( $genero->getId() );
        if( $encontrado === null )
            throw new NaoEncontradoException('Genero não encontrado para atualização', 400);
        return $this->repositorio->alterar( $genero ); 
    }

    public function obterPeloId( int $id ):array{
        return $this->repositorio->obterPeloId ( $id );
    }

    public function removerPeloId( int $id ):void{
        $encontrado = $this->repositorio->obterPeloId( $id );
        if( $encontrado === null )
            throw new NaoEncontradoException('Genero não encontrado para remoção', 400);
        $this->repositorio->removerPeloId( $id );
    }
}