<?php
    session_start();
    if( ! isset($_SESSION['usuario'])){
        http_response_code(401);
        die();
    }else{
        if( isset($_SESSION['ultima-atividade']) && ( time() - $_SESSION['ultima-atividade'] ) > 60 ){
            //Destrói a sessão
            session_unset();
            session_destroy();
            http_response_code(401);
            die();
        }else{
            //Renova a sessão
            $_SESSION['ultima-atividade'] = time();
        }
    }    
?>