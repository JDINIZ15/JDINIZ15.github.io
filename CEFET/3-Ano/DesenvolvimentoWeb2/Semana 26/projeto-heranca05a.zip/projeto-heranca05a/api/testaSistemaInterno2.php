<?php
    declare(strict_types=1);
    require_once('autoload.php');

    use cefet\banco\modelo\Cliente;
    use cefet\banco\modelo\Diretor;
    use cefet\banco\modelo\Gerente;
    use cefet\banco\modelo\SistemaInterno;
    use cefet\banco\modelo\Tesoureiro;

    require_once('autoload.php');

    $g1 = new Gerente("Maria Eduarda",123);
    $g2 = new Gerente("Ana Beatriz",124);
    $d1 = new Diretor("Deputado", 123);

    $t1 = new Tesoureiro("Bruno");
    $t1->setSenha(123);

    $c1 = new Cliente("Sophia");
    $c1->setSenha(123);

    $sistemaInterno = new SistemaInterno(123);

    $sistemaInterno->login($g1);
    $sistemaInterno->login($g2);
    $sistemaInterno->login($d1);
    $sistemaInterno->login($t1);
    $sistemaInterno->login($c1);