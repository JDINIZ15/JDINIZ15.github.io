<?php 
declare(strict_types=1);
require_once('autoload.php');

use cefet\banco\modelo\CalculadorDeArea;
use cefet\banco\modelo\Circulo;
use cefet\banco\modelo\Quadrado;
use cefet\banco\modelo\Retangulo;

$calculador = new CalculadorDeArea();
$quadrado = new Quadrado(8);
$retangulo = new Retangulo(10,5);
$retangulo->setLargura(12);
$circulo = new Circulo(10.2);

echo "A altura do retangulo é {$retangulo->altura()}<br/>";
echo "O lado do quadrado é : {$quadrado->lado}.<br/>";
echo "<ht/>Imprimindo as áreas:<br/>";
$calculador->imprimir($quadrado);
$calculador->imprimir($retangulo);
$calculador->imprimir($circulo);