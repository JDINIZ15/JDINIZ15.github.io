<?php 
namespace cefet\banco\modelo;

interface Tributavel{
    public function calculaTributos():float;
}