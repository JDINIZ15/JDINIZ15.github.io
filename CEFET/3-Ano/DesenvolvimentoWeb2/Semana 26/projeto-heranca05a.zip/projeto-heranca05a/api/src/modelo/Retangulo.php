<?php 
    declare(strict_types=1);
    namespace cefet\banco\modelo;

    class Retangulo implements AreaCalculavel{
        //Declarando os atributos(mutáveis) via construtor
        public function __construct(private float $largura, private float $altura)
        {
            //A chamada dos sets é opcional, assim como uma atribuição direta
            $this->setLargura( $largura);
            $this->setAltura($altura);
        }

        public function setLargura(float $largura):void{
            //Regra
            $this->largura = $largura;
        }
        public function setAltura(float $altura):void{
            //Regra
            $this->altura = $altura;
        }

        public function calculaArea(): float
        {
            return $this->largura * $this->altura;
        }
        //O padrão de nomenclatura dos gets costuma mudar
        public function largura():float{
            return $this->largura;
        }
        public function altura():float{
            return $this->altura;
        }

        //Boa prática
        public function toArray(): array
        {
            return [
                'largura' => $this->largura,
                'altura' => $this->altura
            ];
        }
    }
    