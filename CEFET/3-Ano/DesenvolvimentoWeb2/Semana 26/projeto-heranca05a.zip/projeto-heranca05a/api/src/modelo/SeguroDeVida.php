<?php 
namespace cefet\banco\modelo;

class SeguroDeVida implements Tributavel{
    public function calculaTributos(): float
    {
        return 50.0;
    }
}