<?php 
namespace cefet\banco\modelo;

abstract class FuncionarioAutenticavel extends Funcionario{
    protected int $senha;
    public function setSenha(int $senha):void{
        //É possível que haja alguma regra aqui
        $this->senha = $senha;
    }
    public function getSenha():int{
        return $this->senha;
    }

    public function autentica(int $senhaExterna):bool{
        return ($this->senha === $senhaExterna);
    }
}
