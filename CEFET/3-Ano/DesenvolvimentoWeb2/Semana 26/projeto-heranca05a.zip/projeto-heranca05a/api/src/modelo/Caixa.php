<?php
    namespace cefet\banco\modelo;

    class Caixa extends Funcionario{
        private int $numeroDoGuiche;

        public function getBonificacao():float{
            return $this->salario * 0.15;
        }

        //Métodos get e set (próprios do Caixa)
        public function getNumeroDoGuiche():int{
            return $this->numeroDoGuiche;
        }
        public function setNumeroDoGuiche(int $numeroDoGuiche){
            //Pode haver alguma regra
            $this->numeroDoGuiche = $numeroDoGuiche;
        }

    }
?>