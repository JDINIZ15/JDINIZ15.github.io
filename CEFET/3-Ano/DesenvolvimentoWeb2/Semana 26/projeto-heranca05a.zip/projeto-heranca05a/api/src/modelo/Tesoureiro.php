<?php
    namespace cefet\banco\modelo;
    final class Tesoureiro extends Funcionario implements Autenticavel{
        protected int $senha;
        public function setSenha(int $senha):void{
            //É possível que haja alguma regra aqui
            $this->senha = $senha;
        }
        public function getSenha():int{
            return $this->senha;
        }

        public function autentica(int $senhaExterna):bool{
            return ($this->senha === $senhaExterna);
        }
        //Método reescrito
        public function getBonificacao():float{
            return $this->salario * 0.20;
        }

    }
?>