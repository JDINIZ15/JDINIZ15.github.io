<?php 

    namespace cefet\banco\modelo;

    interface AreaCalculavel{
        public function calculaArea():float;
    }

    