<?php
    namespace cefet\banco\modelo;
    class ContaCorrente extends Conta implements Tributavel{
        public function __construct(int $numero, string $nomeDoTitular = "")
        {
            parent::__construct($numero, $nomeDoTitular);
        }

        public function calculaTributos(): float
        {
            return $this->saldo * 0.01;
        }

        public function atualiza(float $taxa):void{
            $this->saldo -= ($taxa * 2);
        }
    }
?>
