<?php
namespace cefet\banco\modelo;
class SistemaInterno{
    private int $senhaSistema;
    public function __construct(int $senhaSistema)
    {
        $this->setSenhaSistema($senhaSistema);
    }

    public function setSenhaSistema(int $senhaSistema):void{
        //regra
        $this->senhaSistema = $senhaSistema;
    }

    public function login(Autenticavel $a):void{
        if($a->autentica($this->senhaSistema))
            echo "Acesso liberado!<br/>";
        else
            echo "Acesso negado.<br/>";
    }
}
