<?php 
    namespace cefet\banco\modelo;

    interface Autenticavel{
        public function autentica(int $senha):bool;
    }
    