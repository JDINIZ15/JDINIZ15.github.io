<?php

class OperacoesMatematicas{
    public static function soma(float $n1, float $n2):float{
        return ($n1+$n2);
    }
        public static function multiplica(float $n1, float $n2):float{
        return ($n1*$n2);
    }
}