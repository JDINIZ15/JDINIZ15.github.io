<?php
    namespace cefet\banco\modelo;
    class Diretor extends Gerente{

        public function __construct(string $nome, int $senha, string $departamento = "NÃO DEFINIDO", float $salario = 1000.0){
            //Tem que ser a primeira linha
            parent::__construct($nome, $senha, $departamento, $salario);
        }

        public final function getBonificacao():float{
            return $this->salario * 0.50;
        }
    }
?>