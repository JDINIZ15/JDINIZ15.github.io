<?php
namespace cefet\banco\modelo;
class ProfessorDoCefet extends FuncionarioDoCefet{
    private float $auxilioAlimentacao = 400;

    public function __construct(string $nome, string $departamento = "NÃO DEFINIDO", float $salario = 1000.0)
    {
        parent::__construct($nome, $departamento, $salario);
    }

    //reescrevendo métodos, ou seja, seu comportamnto
    public function getGastos():float{
        //Invocando o comportamento da superclasse e incrementando
        return parent::getGastos() + $this->auxilioAlimentacao;
    }

    public function getInfo():string{
        return parent::getInfo()." (R\${$this->auxilioAlimentacao} de auxílio alimentação).<br/>";
    }
}
