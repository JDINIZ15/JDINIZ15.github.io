<?php
    declare(strict_types=1);
    require_once('autoload.php');
    use cefet\banco\modelo\Cliente;

    $cliente1 = new Cliente();
    $cliente1->setNome("Fulano");
    $cliente1->setEmail("fulano@gmail.com");
    $cliente1->setCpf("123.456.789-10");

    $cliente2 = new Cliente("Beltrano");
    $cliente2->setEmail("beltrano@gmail.com");
    $cliente2->setCpf("123.456.789-11");

    echo "Cliente 1:<br/>";
    $cliente1->exibeDados();

    echo "Cliente 2:<br/>";
    echo "Nome: {$cliente2->getNome()}<br/>";
    echo "Cpf: {$cliente2->getCpf()}<br/>";
    echo "E-mail: {$cliente2->getEmail()}<br/>";
?>
