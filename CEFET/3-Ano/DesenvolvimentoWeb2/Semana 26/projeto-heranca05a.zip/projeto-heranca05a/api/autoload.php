<?php
spl_autoload_register(function (string $classe) {
    //echo $classe."<hr/>";
    // Remove o namespace base "cefet\banco\"
    $prefixo = 'cefet\\banco';
    $baseDir = 'src';

    // Obtém o caminho relativo da classe (src\modelo\Aluno)
    $caminhoRelativo = str_replace($prefixo,$baseDir, $classe);
    $caminhoRelativo = str_replace('\\',DIRECTORY_SEPARATOR, $caminhoRelativo);

    // Substitui "\" por "/" e acrescenta a extensão .php (src/modelo/Aluno.php)
    $arquivo = $caminhoRelativo . '.php';
    //echo $arquivo."<hr/>";

    // Carrega o arquivo, se existir
    if (file_exists($arquivo)) {
        require_once $arquivo;
    }
});
?>