<?php
declare(strict_types=1);
require_once('autoload.php');

use cefet\banco\modelo\Caixa;
use cefet\banco\modelo\Diretor;
use cefet\banco\modelo\GerenciadorDeBonificacoes;
use cefet\banco\modelo\Gerente;
use cefet\banco\modelo\Tesoureiro;

    $gerenciador = new GerenciadorDeBonificacoes();

    //$f1 = new Funcionario("Caio Erthal");
    //$f1->setSalario(2000);//200
    $g1 = new Gerente("Maria Eduarda",123);
    $g1->setSalario(5000);//1500
    $g2 = new Gerente("Ana Beatriz",124);
    $g2->setSalario(5000);//1500
    $t1 = new Tesoureiro("Bruno");
    $t1->setSalario(3000);//600
    $c1 = new Caixa("Jevaux");
    $c1->setSalario(2000);//300
    $d1 = new Diretor("Deputado", 123);
    $d1->setSalario(8000);//4000

    $gerenciador->somaBonificacao($d1);
    $gerenciador->somaBonificacao($g1);
    $gerenciador->somaBonificacao($g2);
    $gerenciador->somaBonificacao($t1);
   // $gerenciador->somaBonificacao($f1);
    $gerenciador->somaBonificacao($c1);
    echo "Total em Bonificações: R\${$gerenciador->getTotalEmBonificacoes()}<br/>";
    //7000
    //8100